if (typeof localStorage === "undefined" || localStorage === null) {
    var LocalStorage = require('node-localstorage').LocalStorage;
    localStorage = LocalStorage('/tmp');  // AWS lambda can only create /tmp folder, not ./tmp
  }
  function rateLimiterLocalStorage({secWindow, allowedHits}) {
    return async (req,res,next) => {
            // var n = new Date().getSeconds();
            const ip = (req.headers['x-forwarded-for'] || req.connection.remoteAddress)

            // if (localStorage.getItem('ip')) {var getIp = localStorage.getItem('ip')};
            // if (!localStorage.getItem('ip')) {var getIp = '::1'};
            console.log('getIp',getIp)
                  if (localStorage.getItem('ip')!==ip) {
                        var requests = 0;
                        requests = requests + 1;
                        console.log('increasing requests a',requests)
                        var n = new Date().getSeconds();
                        localStorage.setItem('requests',requests);
                        localStorage.setItem('ip',ip);
                        console.log('Setting ip')
                        ttl = secWindow;
                        var m = ttl + n ;
                        if (m>60) {m = m - 60};
                        localStorage.setItem('m',m); // 10 sec
                        console.log('timeRemaining',ttl,'currentTime',n,'deadLine',m)
                  } else if (localStorage.getItem('ip')==ip) {
                    console.log('geIp==ip',localStorage.getItem('ip')==ip)
                          var requests = parseInt(localStorage.getItem('requests'));
                          var ttl = parseInt(localStorage.getItem('ttl'));
                          var n = new Date().getSeconds();
                          console.log('getting time remaining',ttl)
                          console.log('got requests',requests);
                            if (!localStorage.getItem('requests')){
                                var requests = 1;
                                localStorage.setItem('requests',requests=1);
                                console.log('err requests',requests)
                            }
                            if (requests == 1) {
                                requests = requests + 1;
                                console.log('increasing requests b',requests)
                                localStorage.setItem('requests',requests);
                                ttl = secWindow;
                                localStorage.setItem('ttl',ttl);  // 0 sec
                                var m = ttl + n ;
                                if (m>60) {m = m - 60};
                                localStorage.setItem('m',m); // 10 sec
                                console.log('uploading deadLine',m);
                                console.log('timeRemaining',ttl,'currentTime',n,'deadLine',m)  
                            } 
                            if (requests>1) {
                                requests = requests + 1;
                                console.log('increasing requests c',requests)
                                localStorage.setItem('requests',requests);
                                  var m = parseInt(localStorage.getItem('m'));
                                    console.log('getting deadLine',m);
                                    if (m<n) {
                                        var ttl = (m + 60) - n;
                                    } else {
                                        var ttl = m - n;
                                    };
                                    localStorage.setItem('ttl',ttl);  // 0 sec
                                    if (m>60) {m = m - 60};
                                    localStorage.setItem('m',m); // 10 sec
                                    console.log('timeRemaining',ttl,'currentTime',n,'deadLine',m);  
    
                              
                                    if (ttl<0 || ttl>secWindow) {
                                        console.log("Time remaining less than 0 or greater than secWindow, restarting clock")
                                        var requests = 1;
                                        localStorage.setItem('requests',requests);
                                    }
                            };
                            if (requests-1>allowedHits) {
                              res.status(503).json({
                                  Response: '503 error',
                                  'Numer of requests per time frame': requests-1,
                                  'Time remaining': ttl + ' secs',
                              })
                            } else { 
                              next(); 
                            }   
                    };               
  
      }
    };
  
    module.exports = rateLimiterLocalStorage;