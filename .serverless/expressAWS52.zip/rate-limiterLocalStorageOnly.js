if (typeof localStorage === "undefined" || localStorage === null) {
    var LocalStorage = require('node-localstorage').LocalStorage;
    localStorage = LocalStorage('/tmp');  // AWS lambda can only create /tmp folder, not ./scratch
  }
  var requests = 0;
  function rateLimiterLocalStorage ({secWindow, allowedHits}) {
      return async (req,res,next) => {
              const ip = (req.headers['x-forwarded-for'] || req.connection.remoteAddress)
              if (localStorage.getItem('ip')!==ip ) {
                  localStorage.setItem('ip',ip);
                  console.log('Setting ip')
                  ttl = secWindow;
                  var n = new Date().getSeconds();
                  localStorage.setItem('n',n);  // 0 sec
                  var m = ttl + n ;
                  if (m>60) {m = m - 60};
                  localStorage.setItem('m',m); // 10 sec
                  console.log('ttl',ttl,'n',n,'m',m)
              } else if (localStorage.getItem('ip')==ip) {
                  requests = requests + 1;
                  console.log('increasing requests',requests)
                  m = localStorage.getItem('m',m);
                  var n = new Date().getSeconds();;
                  ttl = m - n
                  if (ttl>0) {console.log('ttl',ttl,'n',n,'m',m)}
                  if (ttl<0 || ttl>10) {
                    if (m>=60) {m = m - 60};
                    ttl = secWindow;
                    requests = 0;
                    var n = new Date().getSeconds();
                    localStorage.setItem('n',n);  // 0 sec
                    var m = ttl + n ;
                    
                    localStorage.setItem('m',m); // 10 sec
                    console.log('NEW ttl',ttl,'NEW n',n,'NEW m',m)
                  }
                }
              if (requests>=allowedHits) {
                  return res.status(503).json({
                      Response: '503 error',
                      'Numer of requests per time frame': requests,
                      'Time remaining before you can make another requests': ttl + ' sec'
                  })
              } 
              else {
                  next();
              }
      }
  };
  module.exports = rateLimiterLocalStorage;