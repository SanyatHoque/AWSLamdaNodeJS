const express = require('express');
const cors = require('cors');
var app = express();
const bodyParser = require('body-parser');

const {pool} = require('./pool');

// SKIPPING THIS PART DUE TO DEPLOYEMENT IN LAMBDA
// const port = 5000;
// app.listen(port, function (err) {
//   if (err) {
//     console.error(err)
//     process.exit(1)
//   } else {
//     console.log(`Listening on port ${port}`)
//   }
// })

app.use((req, res, next) => {
  res.header("Access-Control-Allow-Origin", "*");
  res.header("Access-Control-Allow-Headers", "Content-Type");
  res.header("Access-Control-Allow-Methods", "GET, POST");
  next();
});

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// const redis = require('./redis-client');

// if (typeof localStorage === "undefined" || localStorage === null) {
//   var LocalStorage = require('node-localstorage').LocalStorage;
//   localStorage = new LocalStorage('/tmp');  // AWS lambda can only create /tmp folder, not ./scratch
// }
// var requests = 0;
// function rateLimiter ({secWindow, allowedHits}) {
//     return async (req,res,next) => {
//             const ip = (req.headers['x-forwarded-for'] || req.connection.remoteAddress)
//             if (localStorage.getItem('ip')!==ip ) {
//                 localStorage.setItem('ip',ip);
//                 console.log('Setting ip')
//                 ttl = secWindow;
//                 var n = new Date().getSeconds();
//                 localStorage.setItem('n',n);  // 0 sec
//                 var m = ttl + n ;
//                 if (m>60) {m = m - 60};
//                 localStorage.setItem('m',m); // 10 sec
//                 console.log('ttl',ttl,'n',n,'m',m)
//             } else if (localStorage.getItem('ip')==ip) {
//                 requests = requests + 1;
//                 console.log('increasing requests',requests)
//                 m = localStorage.getItem('m',m);
//                 var n = new Date().getSeconds();;
//                 ttl = m - n
//                 if (ttl>0) {console.log('ttl',ttl,'n',n,'m',m)}
//                 if (ttl<0 || ttl>10) {
//                   if (m>=60) {m = m - 60};
//                   ttl = secWindow;
//                   requests = 0;
//                   var n = new Date().getSeconds();
//                   localStorage.setItem('n',n);  // 0 sec
//                   var m = ttl + n ;
//                   localStorage.setItem('m',m); // 10 sec
//                   console.log('NEW ttl',ttl,'NEW n',n,'NEW m',m)
//                 }
//               }
//             if (requests>=allowedHits) {
//                 return res.status(503).json({
//                     Response: '503 error',
//                     'Numer of requests per time frame': requests,
//                     'Time remaining before you can make another requests': ttl + ' sec'
//                 })
//             } 
//             else {
//                 next();
//             }
//     }
// };

// const rateLimiter = require('./rate-limiter')

const rateLimiter = require('./rate-limiterLocalStorageOnly')
// localStorage.removeItem('ip')
// localStorage.removeItem('m')
// localStorage.removeItem('n')

const queryHandler = (req, res, next) => {
  pool.query(req.sqlQuery).then((r) => {
    return res.json(r.rows || [])
  }).catch(next)
}

app.get('/', rateLimiter({secWindow:10,allowedHits:2}), async (req, res) => {
    res.send(`Welcome to EQ Works 😎`)
})

app.get('/events/hourly', rateLimiter({secWindow:10,allowedHits:2}), async (req, res, next) => {
  req.sqlQuery = `
    SELECT date, hour, events
    FROM public.hourly_events
    ORDER BY date, hour
    LIMIT 168;
  `
  return next()
}, queryHandler)

app.get('/events/daily', rateLimiter({secWindow:10,allowedHits:2}), async (req, res, next) => {
  req.sqlQuery = `
    SELECT date, SUM(events) AS events
    FROM public.hourly_events
    GROUP BY date
    ORDER BY date
    LIMIT 7;
  `
  return next()
}, queryHandler)

app.get('/stats/hourly', rateLimiter({secWindow:10,allowedHits:2}), async (req, res, next) => {
  req.sqlQuery = `
    SELECT date, hour, impressions, clicks, revenue
    FROM public.hourly_stats
    ORDER BY date, hour
    LIMIT 168;
  `
  return next()
}, queryHandler)

app.get('/stats/daily', rateLimiter({secWindow:10,allowedHits:2}), async (req, res, next) => {
  req.sqlQuery = `
    SELECT date,
        SUM(impressions) AS impressions,
        SUM(clicks) AS clicks,
        SUM(revenue) AS revenue
    FROM public.hourly_stats
    GROUP BY date
    ORDER BY date
    LIMIT 7;
  `
  return next()
}, queryHandler)

app.get('/poi', rateLimiter({secWindow:10,allowedHits:2}), async (req, res, next) => {
  req.sqlQuery = `
    SELECT *
    FROM public.poi;
  `
  return next()
}, queryHandler)

// last resorts
process.on('uncaughtException', (err) => {
  console.log(`Caught exception: ${err}`)
  process.exit(1)
})
process.on('unhandledRejection', (reason, p) => {
  console.log('Unhandled Rejection at: Promise', p, 'reason:', reason)
  process.exit(1)
})


module.exports = app;